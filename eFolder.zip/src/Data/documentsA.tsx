export default [
  {
    id: 1,
    name: "CV.pdf",
    category: "A",
    size: "10.87MB",
    uploadTime: "2022-11-14 18:25:17",
  },
  {
    id: 2,
    name: "Aneks-6557.pdf",
    category: "B",
    size: 1039832,
    uploadTime: "2022-11-14 18:25:17",
  },
  {
    id: 3,
    name: "Oświadczenie_Lekarskie.pdf",
    category: "A",
    size: "10.87MB",
    uploadTime: "2022-11-14 18:25:17",
  },
  {
    id: 4,
    name: "Zgoda_RODO.pdf",
    category: "B",
    size: "182.kB",
    uploadTime: "2022-11-14 18:25:17",
  },
  {
    id: 1,
    name: "CV.pdf",
    category: "A",
    size: "10.87MB",
    uploadTime: "2022-11-14 18:25:17",
  },
  {
    id: 1,
    name: "CV.pdf",
    category: "B",
    size: 1039832,
    uploadTime: "2022-11-14 18:25:17",
  },
];
