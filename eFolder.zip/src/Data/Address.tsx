export default [
  {
    firstname: "Max",
    lastname: "McKinley",
    country: "UK",
    county: "County of London",
    city: "London",
    street: "Baker's Street",
    buildingNumber: "226B",
    flatNumber: "4",
    zipcode: "344-9672",
  },
];
