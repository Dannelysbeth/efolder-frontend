export const genderPOL = {
  MALE: "Mężczyzna",
  FEMALE: "Kobieta",
  OTHER: "Osoba niebinarna",
  DONT_TELL: "Informacja zastrzeżona",
};
