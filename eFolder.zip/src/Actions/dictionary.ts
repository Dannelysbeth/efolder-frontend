export const dictionary = {
  year: "Rok",
  threeMonths: "3 miesiące",
  month: "miesiąc",
  twoWeeks: "2 tygodnie",
  week: "tydzień",
  threeDays: "3 dni",
  day: "dzień",
  fourHours: "4 godziny",
  twoHours: "2 godziny",
  MALE: "Mężczyzna",
  FEMALE: "Kobieta",
};
