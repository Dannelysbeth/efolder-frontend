import React from 'react';
import { Component, ReactNode, useEffect, useState } from "react"



const BlankPage = () => {
    return (
        <div>
        </div>
    )
}

export default BlankPage;