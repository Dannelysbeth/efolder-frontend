import React from "react";
import { Component, ReactNode, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./AboutUsPage.css";

const AboutUsPage = () => {
  return (
    <div className="backgd d-flex flex-column min-vh-100">
      <div className="about-container top-space bottom-space"></div>
    </div>
  );
};

export default AboutUsPage;
